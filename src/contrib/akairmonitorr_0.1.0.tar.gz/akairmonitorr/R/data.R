#' ncore_quants dataset
#'
#' @name ncore_quants
#' @docType data
#' @author Simeon \email{simeon.ng@alaska.gov}
#' @keywords data
"ncore_quants"

#' agilaire_flags dataset
#'
#' @name agilaire_flags
#' @docType data
#' @author Simeon \email{simeon.ng@alaska.gov}
#' @keywords data
"agilaire_flags"

#' quant_460 agilaire query quant dataset
#'
#' @name quant_460
#' @docType data
#' @author Simeon \email{simeon.ng@alaska.gov}
#' @keywords data
"quant_460"
